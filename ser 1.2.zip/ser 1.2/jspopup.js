var a = [,"blue", "red","pink","soft","hard","cold","bad","good","old","new","light","dark", "happy", "sad" ,"angry","poor","rich","fat","thin","fast","super","evil","slow",
"green","english","ganster","american","indian","japanes","roadman","lit","gucci","tired","wired","human like","deppresed","gray","orange","yellow","gold","siliver","bronze",
"full","empty","rare","fake","real","smart","dumb","horried","drunk","cute","dull","shy","dim","muilt colour","bright","purple",]


var b = [,"car", "truck","train","bike","House","4x4","bird","hole","space","utc reading", "clown", "killer","fighter","dog","cat","fox","phone","pen","money"
,"space","trump","musk","dino","bat","model","football","gang","prison","world","meme","gucci","skater","boi","jaw","rat","land","room","rod",
"corsair","war","xbox","ps4","apple","scam","fish","class","notepad","coffe","tea","bug","fortnight","minecraft","pubg","peaky","roblocks","pc","fisher","lamp","mug","plant","cartoon","bottle","void","batman",
"iornman","hammer","banna","thug","maths","ink","life","adhd","hair","spot","its coming home","its not coming home home", "team american", "south park","family guy","the simposons","reading","papper","papper clip","usb",
]



random_a = a[Math.floor(Math.random()*a.length)];
random_b = b[Math.floor(Math.random()*b.length)];

search_query = (random_a + "+" + random_b)
google_image_url = "https://www.google.com/search?tbm=isch&q=" + search_query
popup_page = chrome.extension.getBackgroundPage

document.getElementById("search_button").onclick = function(){
    chrome.tabs.create({url: google_image_url})
    console.log("Button Pressed")
}

